import com.sun.jdi.IntegerValue;
import com.sun.jdi.connect.Connector;

public class Main {
    public static void main(String[] args) {
       /* BinaryTree bTree = new BinaryTree();

        //create root
        BinaryTreeNode<Integer> rootNode = new BinaryTreeNode<Integer>();
        rootNode.setElement(7);
        bTree.setRoot(rootNode);

        //create leftChild
        BinaryTreeNode<Integer> leftChild = new BinaryTreeNode<Integer>();
        leftChild.setElement(5);
        rootNode.addLeftChild(leftChild);

        // create rightChild
        BinaryTreeNode<Integer> rightChild = new BinaryTreeNode<Integer>();
        rightChild.setElement(15);
        rootNode.addRightChild(rightChild);

        // create leftChild of 5
        BinaryTreeNode<Integer> leftChildOfFive = new BinaryTreeNode<Integer>();
        leftChildOfFive.setElement(3);
        leftChild.addLeftChild(leftChildOfFive);

        //create rightChild of 5
        BinaryTreeNode<Integer> rightChildOfFive = new BinaryTreeNode<Integer>();
        rightChildOfFive.setElement(6);
        leftChild.addRightChild(rightChildOfFive);

        //create rightChild of 15
        BinaryTreeNode<Integer> rightChildOfFifteen = new BinaryTreeNode<Integer>();
        rightChildOfFifteen.setElement(17);
        rightChild.addRightChild(rightChildOfFifteen);

        System.out.println("InOrder Traversal: " + bTree.inOrder() + "\n"
                + "PreOrder Traversal: " + bTree.preOrder() + "\n"
                + "PostOrder Traversal: " + bTree.postOrder() + "\n"
                + "LevelOrder Traversal: " + bTree.levelOrder() + "\n"
                + "Contains:" + bTree.contains(15) + "\n"
                + "Contains:" + bTree.contains(100));

        BinarySearchTree tree = new BinarySearchTree();
        tree.insert(5);
        tree.insert(10);
        tree.insert(2);
        tree.insert(1);
        tree.insert(3);
        tree.insert(6);
        tree.insert(7);
        tree.insert(12);
        tree.insert(8);
        tree.insert(9);

        System.out.println(tree.levelOrder());
        System.out.println(tree.isBalanced(tree.getRoot()));

        tree.rebalance();

        System.out.println(tree.levelOrder());
        System.out.println(tree.isBalanced(tree.getRoot()));
        */
    }
}
