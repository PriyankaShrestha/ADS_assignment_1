public class BinarySearchTreeNode<E extends Comparable> extends BinaryTreeNode<E> {
    private E element;
}
